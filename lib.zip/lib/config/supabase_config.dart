class SupabaseConfig {
  static const String url = 'https://zynjwqtotldueblhjjji.supabase.co';
  static const String anonKey = 'sb_publishable_Zey5N3k7i2LpVBFdh-02Pw_-GT205Bc';
}