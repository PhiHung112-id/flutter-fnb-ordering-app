import 'package:supabase_flutter/supabase_flutter.dart';

class RankService {
  final SupabaseClient supabase = Supabase.instance.client;

  int getIntValue(dynamic value, {int defaultValue = 0}) {
    if (value == null) return defaultValue;
    if (value is int) return value;
    if (value is num) return value.toInt();

    return int.tryParse(value.toString()) ?? defaultValue;
  }

  double getDoubleValue(dynamic value, {double defaultValue = 0}) {
    if (value == null) return defaultValue;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is num) return value.toDouble();

    return double.tryParse(value.toString()) ?? defaultValue;
  }

  Future<List<Map<String, dynamic>>> getActiveRanks() async {
    final data = await supabase
        .from('customer_ranks')
        .select()
        .eq('is_active', true)
        .order('min_points', ascending: true);

    return List<Map<String, dynamic>>.from(data);
  }

  Future<Map<String, dynamic>?> getRankByPoints(int points) async {
    final data = await supabase
        .from('customer_ranks')
        .select()
        .eq('is_active', true)
        .lte('min_points', points)
        .or('max_points.gte.$points,max_points.is.null')
        .order('min_points', ascending: false)
        .limit(1)
        .maybeSingle();

    if (data == null) {
      return await getLowestRank();
    }

    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>?> getNextRankByPoints(int points) async {
    final data = await supabase
        .from('customer_ranks')
        .select()
        .eq('is_active', true)
        .gt('min_points', points)
        .order('min_points', ascending: true)
        .limit(1)
        .maybeSingle();

    if (data == null) {
      return null;
    }

    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>?> getLowestRank() async {
    final data = await supabase
        .from('customer_ranks')
        .select()
        .eq('is_active', true)
        .order('min_points', ascending: true)
        .limit(1)
        .maybeSingle();

    if (data == null) {
      return null;
    }

    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>> getRankInfoByPoints(int points) async {
    final rankData = await getRankByPoints(points);
    final nextRankData = await getNextRankByPoints(points);

    final currentMin = getIntValue(rankData?['min_points']);
    final nextMin = getIntValue(nextRankData?['min_points']);

    double progress = 1.0;
    int missingPoints = 0;

    if (rankData == null) {
      progress = 0.0;
      missingPoints = 0;
    } else if (nextRankData != null && nextMin > currentMin) {
      progress = ((points - currentMin) / (nextMin - currentMin))
          .clamp(0.0, 1.0);

      missingPoints = nextMin - points;

      if (missingPoints < 0) {
        missingPoints = 0;
      }
    }

    return {
      'rank_data': rankData,
      'next_rank_data': nextRankData,
      'rank': rankData?['name']?.toString() ?? 'Đồng',
      'rank_code': rankData?['code']?.toString() ?? 'bronze',
      'rank_discount': getDoubleValue(rankData?['discount_percent']),
      'points': points,
      'progress': progress,
      'missing_points': missingPoints,
      'next_rank_name': nextRankData?['name']?.toString() ?? 'MAX',
      'next_rank_code': nextRankData?['code']?.toString() ?? '',
    };
  }
}