import 'dart:io';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../utils/rank_style.dart';
import 'rank_service.dart';

class AuthService {
  final SupabaseClient supabase = Supabase.instance.client;

  User? get currentUser => supabase.auth.currentUser;

  bool get isLoggedIn => currentUser != null;

  Future<void> signUp({
    required String email,
    required String password,
    required String fullName,
    required String phone,
  }) async {
    final response = await supabase.auth.signUp(
      email: email.trim(),
      password: password.trim(),
    );

    final user = response.user;

    if (user == null) {
      throw Exception('Không tạo được tài khoản');
    }

    await supabase.from('customers').upsert({
      'id': user.id,
      'full_name': fullName.trim(),
      'phone': phone.trim(),
      'avatar_url': null,
      'points': 0,
      'rank': 'Member',
      'rank_discount': 0,
      'is_admin': false,
    });
  }

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await supabase.auth.signInWithPassword(
      email: email.trim(),
      password: password.trim(),
    );
  }

  Future<void> signOut() async {
    await supabase.auth.signOut();
  }

  Future<void> sendResetPasswordEmail(String email) async {
    final cleanEmail = email.trim();

    if (cleanEmail.isEmpty) {
      throw Exception('Vui lòng nhập email');
    }

    await supabase.auth.resetPasswordForEmail(
      cleanEmail,
      redirectTo: 'io.supabase.chillbites://reset-password',
    );
  }

  Future<void> updateNewPassword(String newPassword) async {
    final password = newPassword.trim();

    if (password.isEmpty) {
      throw Exception('Vui lòng nhập mật khẩu mới');
    }

    if (password.length < 6) {
      throw Exception('Mật khẩu phải có ít nhất 6 ký tự');
    }

    await supabase.auth.updateUser(
      UserAttributes(
        password: password,
      ),
    );
  }

  Future<void> changePassword({
    required String newPassword,
    required String confirmPassword,
  }) async {
    final password = newPassword.trim();
    final confirm = confirmPassword.trim();

    if (password.isEmpty || confirm.isEmpty) {
      throw Exception('Vui lòng nhập đầy đủ mật khẩu');
    }

    if (password.length < 6) {
      throw Exception('Mật khẩu phải có ít nhất 6 ký tự');
    }

    if (password != confirm) {
      throw Exception('Mật khẩu xác nhận không khớp');
    }

    await updateNewPassword(password);
  }

  Future<Map<String, dynamic>?> getProfile() async {
    final user = currentUser;

    if (user == null) {
      return null;
    }

    final data = await supabase
        .from('customers')
        .select(
      'id, full_name, phone, avatar_url, points, rank, rank_discount, is_admin',
    )
        .eq('id', user.id)
        .maybeSingle();

    if (data == null) {
      return null;
    }

    final profile = Map<String, dynamic>.from(data);

    final points = getIntValue(profile['points']);

    final rankData = await RankService().getRankByPoints(points);

    if (rankData != null) {
      final rankName = rankData['name']?.toString() ?? 'Đồng';
      final rankCode = rankData['code']?.toString() ?? 'bronze';
      final discount = getIntValue(rankData['discount_percent']);

      profile['points'] = points;
      profile['rank'] = rankName;
      profile['rank_code'] = rankCode;
      profile['rank_discount'] = discount;
      profile['rank_data'] = rankData;

      await supabase.from('customers').update({
        'rank': rankName,
        'rank_discount': discount,
      }).eq('id', user.id);
    } else {
      profile['points'] = points;
      profile['rank'] = 'Đồng';
      profile['rank_code'] = 'bronze';
      profile['rank_discount'] = 0;
      profile['rank_data'] = null;
    }

    print('PROFILE WITH RANK DATA: $profile');

    return profile;
  }

  int getIntValue(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is num) return value.toInt();

    return int.tryParse(value.toString()) ?? 0;
  }

  Future<String> uploadAvatar({
    required String filePath,
  }) async {
    final user = currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập để đổi ảnh đại diện');
    }

    final extension = filePath.split('.').last;
    final fileName =
        '${user.id}/avatar_${DateTime.now().millisecondsSinceEpoch}.$extension';

    await supabase.storage.from('avatars').upload(
      fileName,
      File(filePath),
      fileOptions: const FileOptions(
        upsert: true,
      ),
    );

    final publicUrl = supabase.storage.from('avatars').getPublicUrl(fileName);
    final avatarUrl = '$publicUrl?v=${DateTime.now().millisecondsSinceEpoch}';

    await supabase.from('customers').update({
      'avatar_url': avatarUrl,
    }).eq('id', user.id);

    return avatarUrl;
  }

  Future<void> updateProfile({
    required String fullName,
    required String phone,
  }) async {
    final user = currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập để cập nhật hồ sơ');
    }

    await supabase.from('customers').update({
      'full_name': fullName.trim(),
      'phone': phone.trim(),
    }).eq('id', user.id);
  }


  Future<Map<String, dynamic>?> getFaceRegistration() async {
    final user = currentUser;

    if (user == null) {
      return null;
    }

    try {
      final data = await supabase
          .from('customers')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

      if (data == null) return null;

      final map = Map<String, dynamic>.from(data);

      return {
        'face_image_url': map['face_image_url'],
        'face_registered_at': map['face_registered_at'],
        'face_register_method': map['face_register_method'],
      };
    } catch (_) {
      return null;
    }
  }

  Future<String> registerFace({
    required String filePath,
  }) async {
    final user = currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập để đăng ký khuôn mặt');
    }

    final extension = filePath.split('.').last.toLowerCase();
    final safeExtension = extension.isEmpty ? 'jpg' : extension;
    final fileName =
        '${user.id}/face_${DateTime.now().millisecondsSinceEpoch}.$safeExtension';

    await supabase.storage.from('avatars').upload(
      fileName,
      File(filePath),
      fileOptions: const FileOptions(
        upsert: true,
      ),
    );

    final publicUrl = supabase.storage.from('avatars').getPublicUrl(fileName);
    final faceUrl = '$publicUrl?v=${DateTime.now().millisecondsSinceEpoch}';

    try {
      await supabase.from('customers').update({
        'face_image_url': faceUrl,
        'face_registered_at': DateTime.now().toIso8601String(),
        'face_register_method': 'camera',
      }).eq('id', user.id);
    } catch (e) {
      throw Exception(
        'Chưa có cột lưu khuôn mặt trong bảng customers. Hãy chạy SQL face_register rồi thử lại. Chi tiết: $e',
      );
    }

    return faceUrl;
  }

  Future<void> deleteRegisteredFace() async {
    final user = currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập để xóa khuôn mặt');
    }

    try {
      await supabase.from('customers').update({
        'face_image_url': null,
        'face_registered_at': null,
        'face_register_method': null,
      }).eq('id', user.id);
    } catch (e) {
      throw Exception(
        'Không xóa được dữ liệu khuôn mặt. Hãy kiểm tra SQL face_register. Chi tiết: $e',
      );
    }
  }

  String getCurrentEmail() {
    return currentUser?.email ?? '';
  }
}