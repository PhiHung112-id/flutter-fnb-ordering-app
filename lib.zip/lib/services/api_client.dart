import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class ApiClient {
  static Uri _uri(String path) {
    final normalizedPath = path.startsWith('/') ? path : '/$path';
    return Uri.parse('${ApiConfig.baseUrl}$normalizedPath');
  }

  static Future<dynamic> get(String path) async {
    final response = await http.get(
      _uri(path),
      headers: const {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
        'API GET $path failed: ${response.statusCode} ${response.body}',
      );
    }

    if (response.body.trim().isEmpty) return null;
    return jsonDecode(response.body);
  }

  static Future<List<Map<String, dynamic>>> getList(String path) async {
    final data = await get(path);

    if (data is List) {
      return data
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    }

    throw Exception('API $path không trả về danh sách');
  }
}
