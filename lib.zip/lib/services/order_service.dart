import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/order_model.dart';
import 'payment_service.dart';

class OrderService {
  final SupabaseClient supabase = Supabase.instance.client;

  String getCurrentUserId() {
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập để đặt hàng');
    }

    return user.id;
  }

  int getIntValue(dynamic value, {int defaultValue = 0}) {
    if (value == null) return defaultValue;
    if (value is int) return value;
    if (value is num) return value.toInt();

    return int.tryParse(value.toString()) ?? defaultValue;
  }

  double getDoubleValue(dynamic value, {double defaultValue = 0}) {
    if (value == null) return defaultValue;
    if (value is num) return value.toDouble();

    return double.tryParse(value.toString()) ?? defaultValue;
  }

  List<dynamic> getToppings(dynamic value) {
    if (value == null) return [];

    if (value is List) {
      return value;
    }

    return [];
  }

  String inferStationType(String productName) {
    final name = productName.toLowerCase().trim();

    final isDrink = name.contains('cà phê') ||
        name.contains('cafe') ||
        name.contains('coffee') ||
        name.contains('bạc xỉu') ||
        name.contains('latte') ||
        name.contains('americano') ||
        name.contains('espresso') ||
        name.contains('trà') ||
        name.contains('tea') ||
        name.contains('sữa') ||
        name.contains('milk') ||
        name.contains('nước') ||
        name.contains('sinh tố') ||
        name.contains('smoothie') ||
        name.contains('đá xay') ||
        name.contains('juice') ||
        name.contains('matcha') ||
        name.contains('cacao') ||
        name.contains('soda') ||
        name.contains('yaourt');

    return isDrink ? 'bar' : 'kitchen';
  }

  bool isSePayPayment(String paymentMethod) {
    final value = paymentMethod.toLowerCase().trim();

    return value == 'sepay' ||
        value == 'sepay vietqr' ||
        value == 'vietqr' ||
        value.contains('sepay') ||
        value.contains('vietqr');
  }

  String normalizePaymentMethod(String paymentMethod) {
    final raw = paymentMethod.trim();

    if (raw.isEmpty) return 'cash';

    if (isSePayPayment(raw)) return 'SePay VietQR';

    return raw;
  }

  String normalizeOrderStatus({
    required bool useSePay,
  }) {
    if (useSePay) return 'Chờ thanh toán';

    return 'Chờ xác nhận';
  }

  Future<int> createOrder({
    required String customerName,
    required String phone,
    required String address,
    required String note,
    required String paymentMethod,
    String orderType = 'delivery',
    required double subtotal,
    required double shippingFee,
    required double discount,
    required double total,
    required List<Map<String, dynamic>> items,
  }) async {
    final userId = getCurrentUserId();
    final useSePay = isSePayPayment(paymentMethod);
    final now = DateTime.now().toUtc().toIso8601String();
    final cleanPaymentMethod = normalizePaymentMethod(paymentMethod);
    final orderStatus = normalizeOrderStatus(useSePay: useSePay);

    final payload = <String, dynamic>{
      'user_id': userId,
      'customer_id': userId,
      'customer_name': customerName.trim(),
      'phone': phone.trim(),
      'customer_phone': phone.trim(),
      'address': address.trim(),
      'note': note.trim(),
      'payment_method': cleanPaymentMethod,
      'payment_status': useSePay ? 'pending' : 'unpaid',
      'status': orderStatus,
      'fulfillment_status': 'new',
      'order_source': 'customer_app',
      'source': 'customer_app',
      'order_type': orderType.trim().isEmpty ? 'delivery' : orderType.trim(),
      'subtotal': subtotal,
      'shipping_fee': shippingFee,
      'discount': discount,
      'total': total,
      'total_amount': total,
      'created_at': now,
    };

    final orderData = await supabase
        .from('orders')
        .insert(payload)
        .select('id')
        .single();

    final orderId = getIntValue(orderData['id']);

    final orderItems = items.map((item) {
      final productId = item['productId'] ??
          item['product_id'] ??
          item['id'];

      final qty = item['qty'] ??
          item['quantity'] ??
          1;

      final title = item['title'] ??
          item['product_title'] ??
          item['name'] ??
          'Sản phẩm';

      final thumbnail = item['thumbnail'] ??
          item['product_thumbnail'] ??
          item['image'] ??
          '';

      return {
        'order_id': orderId,
        'product_id': getIntValue(productId),
        'product_title': title.toString(),
        'product_name_at_sale': title.toString(),
        'product_thumbnail': thumbnail.toString(),
        'price': getDoubleValue(item['price']),
        'qty': getIntValue(qty, defaultValue: 1),
        'quantity': getIntValue(qty, defaultValue: 1),
        'toppings': getToppings(item['toppings']),
        'station_type': inferStationType(title.toString()),
        'fulfillment_status': 'new',
      };
    }).where((item) {
      return getIntValue(item['product_id']) > 0;
    }).toList();

    if (orderItems.isNotEmpty) {
      await supabase.from('order_items').insert(orderItems);
    }

    // Nếu khách chọn SePay/VietQR thì tạo mã thanh toán + link QR.
    if (useSePay) {
      await PaymentService().createSePayPayment(
        orderId: orderId,
        amount: total,
      );
    }

    return orderId;
  }


  Future<void> cancelOrder({
    required int orderId,
    String reason = 'Khách hủy đơn',
  }) async {
    final userId = getCurrentUserId();

    try {
      await supabase.rpc(
        'customer_cancel_order',
        params: {
          'p_order_id': orderId.toString(),
          'p_user_id': userId,
          'p_reason': reason.trim().isEmpty ? 'Khách hủy đơn' : reason.trim(),
        },
      );
    } catch (e) {
      // Fallback cho DB chưa có RPC, vẫn chỉ cho hủy đơn của chính user.
      await supabase
          .from('orders')
          .update({
            'status': 'Đã hủy',
            'fulfillment_status': 'cancelled',
            'cancel_reason': reason.trim().isEmpty ? 'Khách hủy đơn' : reason.trim(),
            'cancel_note': 'cancelled_by_customer_app',
            'cancelled_at': DateTime.now().toUtc().toIso8601String(),
          })
          .eq('id', orderId)
          .eq('user_id', userId);
    }
  }

  Future<List<OrderModel>> getMyOrders() async {
    final userId = getCurrentUserId();

    final data = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('user_id', userId)
        .order('id', ascending: false);

    final list = List<Map<String, dynamic>>.from(data);

    return list.map((json) {
      return OrderModel.fromSupabase(json);
    }).toList();
  }

  Future<OrderModel?> getOrderDetail(int orderId) async {
    final userId = getCurrentUserId();

    final data = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('id', orderId)
        .eq('user_id', userId)
        .maybeSingle();

    if (data == null) {
      return null;
    }

    return OrderModel.fromSupabase(Map<String, dynamic>.from(data));
  }

  Future<void> updateOrderStatus({
    required int orderId,
    required String status,
  }) async {
    final userId = getCurrentUserId();

    if (status == 'Đã hủy') {
      await cancelOrder(orderId: orderId);
      return;
    }

    await supabase
        .from('orders')
        .update({
      'status': status,
    })
        .eq('id', orderId)
        .eq('user_id', userId);
  }
}