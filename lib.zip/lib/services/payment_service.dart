import 'package:supabase_flutter/supabase_flutter.dart';

class PaymentService {
  final SupabaseClient supabase = Supabase.instance.client;

  static const String sePayBankCode = 'MBBank';
  static const String sePayAccountNumber = '011614088888';
  static const String sePayAccountHolder = 'NGUYEN PHI HUNG';
  static const String sePayStoreName = 'CHILL BITES';

  String getCurrentUserId() {
    final user = supabase.auth.currentUser;

    if (user == null) {
      throw Exception('Bạn cần đăng nhập');
    }

    return user.id;
  }

  int toVndAmount(double amount) {
    return amount.round();
  }

  String createPaymentCode(int orderId) {
    return 'CB$orderId';
  }

  String createSePayQrUrl({
    required int orderId,
    required double amount,
  }) {
    final paymentCode = createPaymentCode(orderId);
    final amountVnd = toVndAmount(amount);

    final uri = Uri.https(
      'qr.sepay.vn',
      '/img',
      {
        'acc': sePayAccountNumber,
        'bank': sePayBankCode,
        'amount': amountVnd.toString(),
        'des': paymentCode,
        'template': 'compact',
        'showinfo': 'true',
        'holder': sePayAccountHolder,
        'store': sePayStoreName,
      },
    );

    return uri.toString();
  }

  Future<Map<String, dynamic>> createSePayPayment({
    required int orderId,
    required double amount,
  }) async {
    final userId = getCurrentUserId();

    final paymentCode = createPaymentCode(orderId);
    final qrUrl = createSePayQrUrl(
      orderId: orderId,
      amount: amount,
    );

    await supabase
        .from('orders')
        .update({
      'payment_method': 'SePay VietQR',
      'payment_status': 'pending',
      'status': 'Chờ thanh toán',
      'fulfillment_status': 'new',
      'order_source': 'customer_app',
      'source': 'customer_app',
      'payment_code': paymentCode,
      'payment_qr_url': qrUrl,
    })
        .eq('id', orderId)
        .eq('user_id', userId);

    return {
      'order_id': orderId,
      'amount': amount,
      'payment_code': paymentCode,
      'qr_url': qrUrl,
      'payment_status': 'pending',
    };
  }

  Future<String> getOrderPaymentStatus(int orderId) async {
    final userId = getCurrentUserId();

    final data = await supabase
        .from('orders')
        .select('payment_status')
        .eq('id', orderId)
        .eq('user_id', userId)
        .maybeSingle();

    return data?['payment_status']?.toString() ?? 'unpaid';
  }

  Future<Map<String, dynamic>?> getOrderPaymentInfo(int orderId) async {
    final userId = getCurrentUserId();

    final data = await supabase
        .from('orders')
        .select(
      'id, total, total_amount, payment_method, payment_status, payment_code, payment_qr_url',
    )
        .eq('id', orderId)
        .eq('user_id', userId)
        .maybeSingle();

    if (data == null) {
      return null;
    }

    return Map<String, dynamic>.from(data);
  }

  Future<List<Map<String, dynamic>>> getPaymentMethods() async {
    final userId = getCurrentUserId();

    final defaultMethods = <Map<String, dynamic>>[
      {
        'id': 'cash',
        'user_id': userId,
        'type': 'cash',
        'title': 'Thanh toán khi nhận hàng',
        'subtitle': 'Trả tiền mặt khi nhận món',
      },
      {
        'id': 'sepay',
        'user_id': userId,
        'type': 'sepay',
        'title': 'SePay VietQR',
        'subtitle': 'Quét mã QR ngân hàng để thanh toán online',
      },
    ];

    final data = await supabase
        .from('payment_methods')
        .select()
        .eq('user_id', userId)
        .order('id', ascending: true);

    final savedMethods = List<Map<String, dynamic>>.from(data);

    return [
      ...defaultMethods,
      ...savedMethods,
    ];
  }

  Future<void> addPaymentMethod({
    required String type,
    required String title,
    required String subtitle,
  }) async {
    final userId = getCurrentUserId();

    await supabase.from('payment_methods').insert({
      'user_id': userId,
      'type': type,
      'title': title,
      'subtitle': subtitle,
    });
  }

  Future<void> deletePaymentMethod(int id) async {
    final userId = getCurrentUserId();

    await supabase
        .from('payment_methods')
        .delete()
        .eq('id', id)
        .eq('user_id', userId);
  }
}